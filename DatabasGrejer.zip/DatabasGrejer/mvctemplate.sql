-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1:3306
-- Tid vid skapande: 23 feb 2020 kl 14:45
-- Serverversion: 5.7.24
-- PHP-version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `mvctemplate`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `text` varchar(255) NOT NULL,
  `post_fk` int(11) NOT NULL,
  `comment_pk` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`comment_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `comments`
--

INSERT INTO `comments` (`text`, `post_fk`, `comment_pk`) VALUES
('Det där är en riktigt fräck bil!', 1, 1),
('Nice kärry du har.', 2, 2),
('Det håller jag med om.', 1, 3);

-- --------------------------------------------------------

--
-- Tabellstruktur `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `rubrik` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `bild` varchar(255) NOT NULL,
  `post_pk` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`post_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `posts`
--

INSERT INTO `posts` (`rubrik`, `text`, `bild`, `post_pk`) VALUES
('Bil', 'Har en bil som ska bort', 'Jättefin bild', 1),
('Böttad kärry', 'Har böttat kundvagnen Kärry', 'Fin bild på böttad Kärry', 2);

-- --------------------------------------------------------

--
-- Tabellstruktur `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `username_pk` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `post_fk` varchar(255) NOT NULL,
  `comments_fk` varchar(255) NOT NULL,
  PRIMARY KEY (`username_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
