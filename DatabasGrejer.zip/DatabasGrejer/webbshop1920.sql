-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1:3306
-- Tid vid skapande: 23 feb 2020 kl 14:48
-- Serverversion: 5.7.24
-- PHP-version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `webbshop1920`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `artiklar`
--

DROP TABLE IF EXISTS `artiklar`;
CREATE TABLE IF NOT EXISTS `artiklar` (
  `bild` varchar(255) NOT NULL,
  `namn` varchar(255) NOT NULL,
  `pris` int(10) NOT NULL,
  `beskrivning` text NOT NULL,
  `artid_pk` int(255) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`artid_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `artiklar`
--

INSERT INTO `artiklar` (`bild`, `namn`, `pris`, `beskrivning`, `artid_pk`) VALUES
('bild.png', 'samsung 49', 1000, 'Riktigt dålig tv, till ett fantastiskt pris', 1),
('bild.png', 'lg 75', 10000, 'stor tv som laksjdfökljölkj ölkjasdölfkjöl jkasjdfk.', 2);

-- --------------------------------------------------------

--
-- Tabellstruktur `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `artid_fk` int(255) NOT NULL,
  `userid_fk` int(255) NOT NULL,
  `antal` int(10) NOT NULL,
  `cartid_pk` int(255) NOT NULL,
  PRIMARY KEY (`cartid_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
